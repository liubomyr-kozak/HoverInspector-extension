var debug = true;
var tabs = {};


var PATH_TO_CSS_FILE = 'webpage.chrome.css';
var PATH_TO_JS_FILE = 'webpage.chrome.js';
var PATH_TO_ZTOOL_16LOGO_FILE = 'images/new_logo2/zTool-16.png';
var PATH_TO_ZTOOL_16LOGO_ACTIVE_FILE = 'images/new_logo2/zTool-16-active.png';
var PATH_TO_ZTOOL_32LOGO_FILE = 'images/new_logo2/zTool-32.png';
var PATH_TO_ZTOOL_32LOGO_ACTIVE_FILE = 'images/new_logo2/zTool-32-active.png';

function toggle(tab) {
    if (!tabs[tab.id])
        addTab(tab);
    else
        deactivateTab(tab.id);
}

function addTab(tab) {
    tabs[tab.id] = Object.create(dimensions);
    tabs[tab.id].activate(tab);
}

function deactivateTab(id) {
    tabs[id].deactivate();
}

function removeTab(id) {
    for (var tabId in tabs) {
        if (tabId == id)
            delete tabs[tabId];
    }
}

var lastBrowserAction = null;

chrome.browserAction.onClicked.addListener(function (tab) {
    if (lastBrowserAction && Date.now() - lastBrowserAction < 10) {
        // fix bug in Chrome Version 49.0.2623.87
        // that triggers browserAction.onClicked twice
        // when called from shortcut _execute_browser_action
        return;
    }
    toggle(tab);
    lastBrowserAction = Date.now();
});

chrome.runtime.onConnect.addListener(function (port) {
    tabs[port.sender.tab.id].initialize(port);
});

chrome.runtime.onSuspend.addListener(function () {
    for (var tabId in tabs) {
        tabs[tabId].deactivate(true);
    }
});


var dimensions = {
    alive: true,

    activate: function (tab) {
        this.tab = tab;

        this.onBrowserDisconnectClosure = this.onBrowserDisconnect.bind(this);


        var extensionVersion = chrome.app.getDetails().version;

        chrome.tabs.executeScript({
            code: `console.log('${extensionVersion}');`
        });

        chrome.tabs.executeScript({
            code: `window.extension = {hoverInspector: {version : '${extensionVersion}'} };`
        });

        chrome.tabs.insertCSS(this.tab.id, {file: PATH_TO_CSS_FILE});
        chrome.tabs.executeScript(this.tab.id, {file: PATH_TO_JS_FILE});


        chrome.browserAction.setIcon({
            tabId: this.tab.id,
            path: {
                16: PATH_TO_ZTOOL_16LOGO_ACTIVE_FILE,
                32: PATH_TO_ZTOOL_32LOGO_ACTIVE_FILE
            }
        });
    },

    deactivate: function (silent) {
        if (!this.port) {
            // not yet initialized
            this.alive = false;
            return;
        }

        if (!silent)
            this.port.postMessage({type: 'destroy'});

        this.port.onDisconnect.removeListener(this.onBrowserDisconnectClosure);

        chrome.browserAction.setIcon({
            tabId: this.tab.id,
            path: {
                16: PATH_TO_ZTOOL_16LOGO_FILE,
                32: PATH_TO_ZTOOL_32LOGO_FILE
            }
        });

        window.removeTab(this.tab.id);
    },

    onBrowserDisconnect: function () {
        this.deactivate(true);
    },

    initialize: function (port) {
        this.port = port;

        if (!this.alive) {
            // was deactivated whilest still booting up
            this.deactivate();
            return;
        }


        this.port.onDisconnect.addListener(this.onBrowserDisconnectClosure);
        this.port.postMessage({
            type: 'init',
            debug: debug
        });


        const self = this;
        this.port.onMessage.addListener(function (event) {
            if (event === "destroy") {
                self.deactivate();
                return;
            }
        });

    }
};