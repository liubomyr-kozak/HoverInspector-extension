var ModuleZt = ModuleZt || {};

var body = document.querySelector('body');
var port = chrome.runtime.connect({name: "dimensions"});
var paused = true;
var connectionClosed = false;
port.onMessage.addListener(function (event) {
    if (connectionClosed)
        return;

    switch (event.type) {
        case 'distances':
            showDimensions(event.data);
            break;
        case 'destroy':
            destroy();
            break;
    }
});


var isFloat = n => {
    return Number(n) === n && n % 1 !== 0;
};

var ifNumberFloatCut = number => {
    return isFloat(number) ? number.toFixed(2) : number;
};

if (!ModuleZt.hasOwnProperty('Box'))
    ModuleZt.Box = (() => {

        const boxTypes = {
            selected: {},
            hovered: {}
        };

        const createBox = () => {
            const reducer = (boxObject, vector) => {
                boxObject[vector] = document.createElement('div');
                boxObject['all'].push(boxObject[vector]);
                return boxObject
            };
            return ['x', 'x1', 'y', 'y1'].reduce(reducer, {all: []})
        };

        const hoverBoxSetParams = (params) => {
            markBoxAsHover(boxTypes.hovered.all);
            setParamsToNode('hovered', params)
        };

        const setParamsToSelected = (params) => {
            setParamsToNode('selected', params)
        };


        const setParamsToNode = (nodeType, {top, bottom, right, left, height, width}) => {
            boxTypes[nodeType].x.style.top = `${top}px`;
            boxTypes[nodeType].x.style.left = `${right}px`;
            boxTypes[nodeType].x.style.width = "1px";
            boxTypes[nodeType].x.style.height = `${height}px`;

            boxTypes[nodeType].x1.style.top = `${top}px`;
            boxTypes[nodeType].x1.style.left = `${left}px`;
            boxTypes[nodeType].x1.style.width = "1px";
            boxTypes[nodeType].x1.style.height = `${height}px`;

            boxTypes[nodeType].y.style.top = `${top}px`;
            boxTypes[nodeType].y.style.left = `${left}px`;
            boxTypes[nodeType].y.style.width = `${width}px`;
            boxTypes[nodeType].y.style.height = "1px";

            boxTypes[nodeType].y1.style.top = `${bottom}px`;
            boxTypes[nodeType].y1.style.left = `${left}px`;
            boxTypes[nodeType].y1.style.width = `${width}px`;
            boxTypes[nodeType].y1.style.height = "1px";
        };

        const changeHoverBoxToSelect = () => {
            const oldSelected = boxTypes.selected;
            const oldHovered = boxTypes.hovered;

            boxTypes.hovered = oldSelected;
            boxTypes.selected = oldHovered;

            markBoxAsSelected(boxTypes.selected.all);
        };


        const markBoxAsHover = (boxArr) => {
            boxArr.forEach(el => el.className = 'zToolBoxBoxHover');
        };

        const markBoxAsSelected = (boxArr) => {
            boxArr.forEach(el => el.className = 'zToolBoxBoxSelected');
        };

        const registerBox = (boxType, box) => {
            boxTypes[boxType] = box;
            boxTypes[boxType].isDisplay = false;
        };

        const getBoxByType = boxType => {
            return boxTypes[boxType];
        };

        const toggleAllBoxes = flag => {

            boxTypes.selected.isDisplay = false;
            boxTypes.hovered.isDisplay = false;

            boxTypes.hovered.all.forEach(el => el.style.display = flag === 'hide' ? 'none' : 'block');
            boxTypes.selected.all.forEach(el => el.style.display = flag === 'hide' ? 'none' : 'block');
        };

        return {
            createBox,
            hoverBoxSetParams,
            setParamsToSelected,
            registerBox,
            getBoxByType,
            toggleAllBoxes,
            changeHoverBoxToSelect
        }
    })();

if (!ModuleZt.hasOwnProperty('Distance'))
    ModuleZt.Distance = (() => {

        const getAbsoluteTopNumberMath = value => {
            // if coordinate is -100 that means top position not in view screen
            return value > 0 ? value : 0;
        };

        const getAbsoluteBottomNumberMath = value => {
            const viewPortBottomPosition = window.scrollY + window.innerHeight;

            return viewPortBottomPosition < value ? 0 : value;
        };

        const getLineHeightForBottom = selectedBottomPosition => {
            return window.innerHeight - selectedBottomPosition;
        };


        const createDistanceLine = () => {
            const reducer = (boxObject, vector) => {
                const lineNode = document.createElement('div');
                lineNode.className = `zToolDistanceLine_${vector}`;

                const textNode = document.createElement('span');
                textNode.className = 'zToolDistanceLineLabel';

                lineNode.appendChild(textNode);
                boxObject[vector] = lineNode;
                boxObject['all'].push(boxObject[vector]);
                return boxObject
            };
            return ['x', 'x1', 'y', 'y1'].reduce(reducer, {all: []})
        };

        const distanceLineAndLabels = createDistanceLine();

        const normalizeSideName = sideName => {
            return sideName.split('_')[0]
        };

        const getSideValue = (sideName, selectedElData, hoveredElData) => {
            let side;
            switch (sideName) {

                case 'left_nearVector':
                    side = {
                        coord: selectedElData.right,
                        coord1: hoveredElData.left,
                        value: hoveredElData.left - selectedElData.right,
                    };
                    break;

                case 'left_betweenVector':
                    side = {
                        coord: selectedElData.left,
                        coord1: selectedElData.right,
                        value: hoveredElData.left - selectedElData.left,
                    };
                    break;

                case 'left_outSelectedBox':
                    side = {
                        coord: hoveredElData.left,
                        coord1: selectedElData.left,
                        value: hoveredElData.left - selectedElData.left,
                    };
                    break;

                case 'right_nearVector':
                    side = {
                        coord: hoveredElData.right,
                        coord1: selectedElData.left,
                        value: selectedElData.left - hoveredElData.right,
                    };
                    break;

                case 'right_betweenVector':
                    side = {
                        coord: hoveredElData.right,
                        coord1: selectedElData.right,
                        value: selectedElData.right - hoveredElData.right,
                    };
                    break;
                case 'right_outSelectedBox':
                    side = {
                        coord: selectedElData.right,
                        coord1: hoveredElData.right,
                        value: hoveredElData.right - selectedElData.right,
                    };
                    break;

                case 'top_nearVector':
                    side = {
                        coord: selectedElData.bottom,
                        coord1: hoveredElData.top,
                        value: hoveredElData.top - selectedElData.bottom,
                    };
                    break;

                case 'top_betweenVector':
                    side = {
                        coord: selectedElData.top,
                        coord1: hoveredElData.top,
                        value: hoveredElData.top - selectedElData.top,
                    };
                    break;
                case 'top_outSelectedBox':
                    side = {
                        coord: hoveredElData.top,
                        coord1: selectedElData.top,
                        value: selectedElData.top - hoveredElData.top,
                    };
                    break;


                case 'bottom_nearVector':
                    side = {
                        coord: hoveredElData.bottom,
                        coord1: selectedElData.top,
                        value: selectedElData.top - hoveredElData.bottom,
                    };
                    break;
                case 'bottom_betweenVector':
                    side = {
                        coord: hoveredElData.bottom,
                        coord1: selectedElData.bottom,
                        value: selectedElData.bottom - hoveredElData.bottom,
                    };
                    break;
                case 'bottom_outSelectedBox':
                    side = {
                        coord: selectedElData.bottom,
                        coord1: hoveredElData.bottom,
                        value: hoveredElData.bottom - selectedElData.bottom,
                    };
                    break;
            }

            return side
        };

        const calculateDistance = (hoveredElData, selectedElData) => {
            if (!selectedElData) {
                return
            }

            const availableSideType = [];

            availableSideType.push(
                selectedElData.right < hoveredElData.left && 'left_nearVector'
            );
            availableSideType.push(
                selectedElData.right > hoveredElData.left &&
                selectedElData.left < hoveredElData.left && 'left_betweenVector'
            );
            availableSideType.push(
                selectedElData.left > hoveredElData.left &&
                selectedElData.right < hoveredElData.right && 'left_outSelectedBox'
            );


            availableSideType.push(
                selectedElData.left > hoveredElData.right && 'right_nearVector'
            );
            availableSideType.push(
                selectedElData.left < hoveredElData.right &&
                selectedElData.right > hoveredElData.right && 'right_betweenVector'
            );
            availableSideType.push(
                selectedElData.right < hoveredElData.right &&
                selectedElData.left > hoveredElData.left && 'right_outSelectedBox'
            );


            availableSideType.push(
                selectedElData.bottom < hoveredElData.top && 'top_nearVector'
            );
            availableSideType.push(
                selectedElData.bottom > hoveredElData.top &&
                selectedElData.top < hoveredElData.top && 'top_betweenVector'
            );
            availableSideType.push(
                selectedElData.top > hoveredElData.top &&
                selectedElData.bottom < hoveredElData.bottom && 'top_outSelectedBox'
            );

            availableSideType.push(
                selectedElData.top > hoveredElData.bottom && 'bottom_nearVector'
            );
            availableSideType.push(
                selectedElData.top < hoveredElData.top &&
                selectedElData.bottom > hoveredElData.bottom && 'bottom_betweenVector'
            );
            availableSideType.push(
                selectedElData.top > hoveredElData.top &&
                selectedElData.bottom < hoveredElData.bottom && 'bottom_outSelectedBox'
            );


            const centeredBySelectedNode_TopBottom = availableSideType.indexOf('left_outSelectedBox') >= 0 &&
                availableSideType.indexOf('right_outSelectedBox') >= 0;

            const centeredBySelectedNode_Side = availableSideType.indexOf('top_outSelectedBox') >= 0 &&
                availableSideType.indexOf('bottom_outSelectedBox') >= 0;


            // console.log(availableSideType);
            // console.log('centeredBySelectedNode_TopBottom', centeredBySelectedNode_TopBottom);
            // console.log('switchSideBottom', centeredBySelectedNode_Side);

            return availableSideType.reduce((obj, side) => {
                    if (side) {
                        obj[normalizeSideName(side)] = {
                            type: side,
                            side: getSideValue(side, selectedElData, hoveredElData)
                        }
                    }
                    return obj;
                },
                {
                    x: centeredBySelectedNode_Side
                        ? selectedElData.top + selectedElData.height / 2
                        : hoveredElData.top + hoveredElData.height / 2,
                    y: centeredBySelectedNode_TopBottom
                        ? selectedElData.left + selectedElData.width / 2
                        : hoveredElData.left + hoveredElData.width / 2
                }
            );
        };

        const dispatchDistanceLineAndLabel = data => {

            if (data.right) {
                const {side, type} = data.right;

                distanceLineAndLabels.x.style.display = `block`;
                distanceLineAndLabels.x.style.height = '1px';
                distanceLineAndLabels.x.style.width = `${Math.abs(side.value)}px`;
                distanceLineAndLabels.x.style.top = `${Math.abs(data.x)}px`;
                distanceLineAndLabels.x.style.left = `${Math.abs(side.coord)}px`;

                distanceLineAndLabels.x.childNodes[0].innerHTML = `${ifNumberFloatCut(Math.abs(side.value))}px`;
            } else {
                distanceLineAndLabels.x.style.display = `none`;
            }

            if (data.left) {
                const {side, type} = data.left;

                distanceLineAndLabels.x1.style.display = `block`;
                distanceLineAndLabels.x1.style.height = '1px';
                distanceLineAndLabels.x1.style.width = `${Math.abs(side.value)}px`;
                distanceLineAndLabels.x1.style.top = `${Math.abs(data.x)}px`;
                distanceLineAndLabels.x1.style.left = `${Math.abs(side.coord)}px`;

                distanceLineAndLabels.x1.childNodes[0].innerHTML = `${ifNumberFloatCut(Math.abs(side.value))}px`
            } else {
                distanceLineAndLabels.x1.style.display = `none`;
            }

            if (data.top) {
                const {side, type} = data.top;


                const topCoordinate = getAbsoluteTopNumberMath(side.coord);
                const lineHeight = topCoordinate === 0 ? (side.value - Math.abs(side.coord)) : Math.abs(side.value);


                distanceLineAndLabels.y.style.display = `block`;
                distanceLineAndLabels.y.style.height = `${lineHeight}px`;
                distanceLineAndLabels.y.style.width = '1px';
                distanceLineAndLabels.y.style.top = `${topCoordinate}px`;
                distanceLineAndLabels.y.style.left = `${Math.abs(data.y)}px`;

                distanceLineAndLabels.y.childNodes[0].innerHTML = `${ifNumberFloatCut(Math.abs(side.value))}px`;
            } else {
                distanceLineAndLabels.y.style.display = `none`;
            }

            if (data.bottom) {
                const {side, type} = data.bottom;

                const topCoordinate = getAbsoluteBottomNumberMath(side.coord1);
                const lineHeight = topCoordinate === 0 ? getLineHeightForBottom(side.coord) : Math.abs(side.value);

                distanceLineAndLabels.y1.style.display = `block`;
                distanceLineAndLabels.y1.style.height = `${lineHeight}px`;
                distanceLineAndLabels.y1.style.width = '1px';
                distanceLineAndLabels.y1.style.top = `${Math.abs(side.coord)}px`;
                distanceLineAndLabels.y1.style.left = `${Math.abs(data.y)}px`;

                distanceLineAndLabels.y1.childNodes[0].innerHTML = `${ifNumberFloatCut(Math.abs(side.value))}px`;
            } else {
                distanceLineAndLabels.y1.style.display = `none`;
            }
        };

        const getDistanceLineAndLabels = () => distanceLineAndLabels;


        const toggleLinesAndLabels = (flag) => {
            distanceLineAndLabels.all.forEach(el => el.style.display = flag === 'hide' ? 'none' : 'block');
        };

        return {
            calculateDistance,
            dispatchDistanceLineAndLabel,
            getDistanceLineAndLabels,
            toggleLinesAndLabels
        }
    })();

if (!ModuleZt.hasOwnProperty('BoxLabels'))
    ModuleZt.BoxLabels = (() => {

        let labelNode;

        const createBoxLabel = () => {
            const label = document.createElement('div');
            label.className = 'zToolBoxLabel';

            return label;
        };


        const labelParams = ({top, bottom, right, left, height, width}) => {

            labelNode.innerHTML = `${ifNumberFloatCut(height)}px x ${ifNumberFloatCut(width)}px`;

            const middleX = left
                ? left + (width / 2) - (90 / 2)
                : right - (width / 2) - (90 / 2);


            const middleY = top
                ? top - 27
                : bottom + 27;

            labelNode.style.top = `${middleY}px`;
            labelNode.style.left = `${middleX}px`;
        };


        const registerLabel = label => {
            labelNode = label;
        };

        const getLabel = () => labelNode;

        const toggleLabel = flag => {
            labelNode.style.display = flag === 'hide' ? 'none' : 'block';
        };

        return {
            createBoxLabel,
            labelParams,
            registerLabel,
            getLabel,
            toggleLabel
        }
    })();

if (!ModuleZt.hasOwnProperty('DOM'))
    ModuleZt.DOM = (() => {

        const styleRules = [
            'padding-right', 'padding-left', 'padding-top', 'padding-bottom',
            'margin-right', 'margin-left', 'margin-top', 'margin-bottom',
            'height', 'width', 'font-size'
        ];

        const getStyle = (oElm, strCssRule) => {
            var strValue = "";
            if (document.defaultView && document.defaultView.getComputedStyle) {
                strValue = document.defaultView.getComputedStyle(oElm, "").getPropertyValue(strCssRule);
            }
            else if (oElm.currentStyle) {
                strCssRule = strCssRule.replace(/\-(\w)/g, function (strMatch, p1) {
                    return p1.toUpperCase();
                });
                strValue = oElm.currentStyle[strCssRule];
            }
            return strValue;
        };

        const getStyleByNode = (nodeEl) => {
            return styleRules.reduce((options, ruleName) => {
                    options[ruleName] = getStyle(nodeEl, ruleName);
                    return options
                },
                {}
            )
        };

        const boundingElRect = {
            selected: null,
            hovered: null
        };

        const addBoundingElRect = (type, data) => {
            boundingElRect[type] = data;
        };

        const getBoundingElRect = type => {
            return boundingElRect[type] && boundingElRect[type].clientRect
        };


        const getTargetElByType = type => {
            return boundingElRect[type].target
        };


        return {
            getStyle,
            getStyleByNode,
            addBoundingElRect,
            getBoundingElRect,
            getTargetElByType
        }
    })();

if (!ModuleZt.hasOwnProperty('zToolExtension'))
    ModuleZt.zToolExtension = (() => {
        function renderHoverBox() {
            ModuleZt.Box.getBoxByType('hovered').all.forEach(el => body.appendChild(el));
            ModuleZt.Box.getBoxByType('selected').all.forEach(el => body.appendChild(el));
        }

        function renderLabel() {
            body.appendChild(ModuleZt.BoxLabels.getLabel());
        }

        function renderDistanceLineAndLabel() {
            ModuleZt.Distance.getDistanceLineAndLabels().all.forEach(el => body.appendChild(el));
        }

        function removeHoverBox() {
            ModuleZt.Box.getBoxByType('hovered').all.forEach(el => body.removeChild(el));
            ModuleZt.Box.getBoxByType('selected').all.forEach(el => body.removeChild(el));
        }

        function removeLabel() {
            body.removeChild(ModuleZt.BoxLabels.getLabel());
        }

        return {
            renderDistanceLineAndLabel,
            renderHoverBox,
            renderLabel,
            removeHoverBox,
            removeLabel
        }
    })();

// =====================================================================================================================
// =============================================== CORE STEPS [END] ====================================================
// =====================================================================================================================

// =====================================================================================================================
// INITIAL STEPS
// =====================================================================================================================


function hideBoxes() {
    ModuleZt.Box.toggleAllBoxes('hide');
}

function hideLabel() {
    ModuleZt.BoxLabels.toggleLabel('hide');
}


function displayBox() {
    ModuleZt.Box.toggleAllBoxes('show');
}

function displayLabel() {
    ModuleZt.BoxLabels.toggleLabel('show');
}

function hideDistanceLineAndLabels() {
    ModuleZt.Distance.toggleLinesAndLabels('hide');
}


// =====================================================================================================================
// LET PLAY with BLACK JACK AND Extension
// =====================================================================================================================

function onClick(e) {
    e.preventDefault();
    e.stopPropagation();
}

function onInputMove(e) {
    const hoverElement = e.target;

    // in SVG className is Object
    if (typeof hoverElement.className === 'string'
        && hoverElement.className.indexOf('zTool') >= 0) {
        return true;
    }

    const clientRect = hoverElement.getBoundingClientRect();

    ModuleZt.Box.hoverBoxSetParams(clientRect);
    ModuleZt.BoxLabels.labelParams(clientRect);

    // const hoverNodeParams = ModuleZt.DOM.getStyleByNode(hoverElement);

    ModuleZt.DOM.addBoundingElRect('hovered', {
        target: hoverElement,
        clientRect
    });

    let distance =
        ModuleZt.Distance.calculateDistance(
            ModuleZt.DOM.getBoundingElRect('hovered'),
            ModuleZt.DOM.getBoundingElRect('selected')
        );


    if (distance) {
        ModuleZt.Distance.dispatchDistanceLineAndLabel(distance);
    }
}

function onScroll(e) {
    const selectedNode = ModuleZt.DOM.getTargetElByType('selected');
    const clientRectSelectedNode = selectedNode.getBoundingClientRect();
    ModuleZt.Box.setParamsToSelected(clientRectSelectedNode);

    ModuleZt.DOM.addBoundingElRect('selected', {
        target: selectedNode,
        clientRect: clientRectSelectedNode
    });



    const hoveredNode = ModuleZt.DOM.getTargetElByType('hovered');
    const clientRectHoveredNode = hoveredNode.getBoundingClientRect();

    ModuleZt.Box.hoverBoxSetParams(clientRectHoveredNode);
    ModuleZt.BoxLabels.labelParams(clientRectHoveredNode);

    ModuleZt.DOM.addBoundingElRect('hovered', {
        target: hoveredNode,
        clientRect: clientRectHoveredNode
    });

    let distance =
        ModuleZt.Distance.calculateDistance(
            ModuleZt.DOM.getBoundingElRect('hovered'),
            ModuleZt.DOM.getBoundingElRect('selected')
        );

    if (distance) {
        ModuleZt.Distance.dispatchDistanceLineAndLabel(distance);
    }
}

function onMouseDown(e) {
    const clickedElement = e.target;

    // in SVG className is Object
    if (typeof clickedElement.className === 'string'
        && clickedElement.className.indexOf('zTool') >= 0) {
        return true;
    }

    hideDistanceLineAndLabels();

    const clientRect = clickedElement.getBoundingClientRect();

    ModuleZt.Box.changeHoverBoxToSelect();
    ModuleZt.DOM.addBoundingElRect('selected', {
        target: clickedElement,
        clientRect
    });
    ModuleZt.Box.hoverBoxSetParams(clientRect);
}

function addEventHandler() {
    window.addEventListener('mousemove', onInputMove);
    window.addEventListener('mousedown', onMouseDown);
    window.addEventListener('click', onClick);
    window.addEventListener('scroll', onScroll);
}

function showDimensions(dimensions) {
    if (paused)
        return;

    if (!dimensions)
        return;

    addEventHandler();

    displayBox();
    displayLabel();
}

function initExtension() {
    ModuleZt.Box.registerBox('selected', ModuleZt.Box.createBox());
    ModuleZt.Box.registerBox('hovered', ModuleZt.Box.createBox());
    ModuleZt.BoxLabels.registerLabel(ModuleZt.BoxLabels.createBoxLabel());

    addEventHandler();
}

function destroy() {
    connectionClosed = true;
    hideBoxes();
    hideLabel();
    hideDistanceLineAndLabels();

    window.removeEventListener('mousemove', onInputMove);
    window.removeEventListener('mousedown', onMouseDown);
    window.removeEventListener('click', onClick);
    window.removeEventListener('scroll', onScroll);
}

initExtension();
ModuleZt.zToolExtension.renderHoverBox();
ModuleZt.zToolExtension.renderLabel();
ModuleZt.zToolExtension.renderDistanceLineAndLabel();