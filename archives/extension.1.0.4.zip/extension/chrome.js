var debug = true;
var tabs = {};

function toggle(tab){
  if(!tabs[tab.id])
    addTab(tab);
  else
    deactivateTab(tab.id);
}

function addTab(tab){
  tabs[tab.id] = Object.create(dimensions);
  tabs[tab.id].activate(tab);
}

function deactivateTab(id){
  tabs[id].deactivate();
}

function removeTab(id){
  for(var tabId in tabs){
    if(tabId == id)
      delete tabs[tabId];
  }
}

var lastBrowserAction = null;

chrome.browserAction.onClicked.addListener(function(tab){
  if(lastBrowserAction && Date.now() - lastBrowserAction < 10){
    // fix bug in Chrome Version 49.0.2623.87
    // that triggers browserAction.onClicked twice 
    // when called from shortcut _execute_browser_action
    return;
  }
  toggle(tab);
  lastBrowserAction = Date.now();
});

chrome.runtime.onConnect.addListener(function(port) {
  tabs[ port.sender.tab.id ].initialize(port);
});

chrome.runtime.onSuspend.addListener(function() {
  for(var tabId in tabs){
    tabs[tabId].deactivate(true);
  }
});

var dimensions = {
  alive: true,

  activate: function(tab){
    this.tab = tab;

    this.onBrowserDisconnectClosure = this.onBrowserDisconnect.bind(this);

    chrome.tabs.insertCSS(this.tab.id, { file: 'tooltip.css' });
    chrome.tabs.executeScript(this.tab.id, { file: 'tooltip.chrome.js' });
    chrome.browserAction.setIcon({ 
      tabId: this.tab.id,
      path: {
        16: "images/zTool-16-active.png",
        32: "images/zTool-32-active.png"
      }
    });
  },

  deactivate: function(silent){
    if(!this.port){
      // not yet initialized
      this.alive = false;
      return;
    }

    if(!silent)
      this.port.postMessage({ type: 'destroy' });
    
    this.port.onDisconnect.removeListener(this.onBrowserDisconnectClosure);

    chrome.browserAction.setIcon({  
      tabId: this.tab.id,
      path: {
          16: "images/zTool-16.png",
          32: "images/zTool-32.png"
      }
    });

    window.removeTab(this.tab.id);
  },

  onBrowserDisconnect: function(){
    this.deactivate(true);
  },

  initialize: function(port){
    this.port = port;

    if(!this.alive){
      // was deactivated whilest still booting up
      this.deactivate();
      return;
    }

    this.port.onDisconnect.addListener(this.onBrowserDisconnectClosure);
    this.port.postMessage({
      type: 'init',
      debug: debug
    });
  }
};